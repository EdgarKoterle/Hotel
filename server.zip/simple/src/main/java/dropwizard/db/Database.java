package dropwizard.db;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class Database {
    private Connection conn;
    /*   private String driver = "com.mysql.jdbc.Driver";
       private String url="jdbc:mysql://localhost:3306/hotel";
       private String username="root";
       private String password="root";*/
    public List<String> getRoom() throws Exception{
        Properties props = new Properties();
        FileInputStream fis = null;
        fis = new FileInputStream("db.properties");
        props.load(fis);

        List<String> list = new ArrayList<>();
        try {
            Class.forName(props.getProperty("DB_DRIVER_CLASS"));
            // conn = DriverManager.getConnection(url,username,password);
            conn = DriverManager.getConnection(props.getProperty("DB_URL"),
                    props.getProperty("DB_USERNAME"),
                    props.getProperty("DB_PASSWORD"));

            String query = "SELECT free  from room";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                String name=rs.getString("free");
                list.add(name);
            }

        }catch(Exception ex){
            System.out.println("Error: "+ ex.getMessage());
        }
        return list;
    }
    public List<String> getFROM() throws Exception{
        Properties props = new Properties();
        FileInputStream fis = null;
        fis = new FileInputStream("db.properties");
        props.load(fis);

        List<String> list2 = new ArrayList<>();
        try {
            Class.forName(props.getProperty("DB_DRIVER_CLASS"));
            // conn = DriverManager.getConnection(url,username,password);
            conn = DriverManager.getConnection(props.getProperty("DB_URL"),
                    props.getProperty("DB_USERNAME"),
                    props.getProperty("DB_PASSWORD"));

            String query = "SELECT start  from room";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                String name=rs.getString("start");
                list2.add(name);
            }

        }catch(Exception ex){
            System.out.println("Error: "+ ex.getMessage());
        }
        return list2;
    }


    public List<String> getTO() throws Exception{
        Properties props = new Properties();
        FileInputStream fis = null;
        fis = new FileInputStream("db.properties");
        props.load(fis);

        List<String> list3 = new ArrayList<>();
        try {
            Class.forName(props.getProperty("DB_DRIVER_CLASS"));
            // conn = DriverManager.getConnection(url,username,password);
            conn = DriverManager.getConnection(props.getProperty("DB_URL"),
                    props.getProperty("DB_USERNAME"),
                    props.getProperty("DB_PASSWORD"));

            String query = "SELECT end  from room";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                String name=rs.getString("end");
                list3.add(name);
            }

        }catch(Exception ex){
            System.out.println("Error: "+ ex.getMessage());
        }
        return list3;
    }

}
