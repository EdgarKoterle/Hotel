package dropwizard.resources;

import dropwizard.db.Database;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.List;

public class EndDate {
    @Path("/world")
    public class Reservation {

        List<String> list;
        @GET
        @Path("/data")
        @Produces(MediaType.APPLICATION_JSON)
        public String getCountries() throws Exception{
            Database mySQL = new Database();
            boolean b= false;
            try {
                list = mySQL.getTO();
                System.out.println(list);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }String result= "fun( ["+  list.get(0) +" ," + list.get(1)  +" ," + list.get(2) +" ," + list.get(3)  +" ," + list.get(4)     +"])";
            return result;
        } }



}
