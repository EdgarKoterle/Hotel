package dropwizard.resources;


import dropwizard.db.Database;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/world")
public class View {
    List<String> list;
    @GET
    @Path("/company")
    @Produces(MediaType.APPLICATION_JSON)
    public String getCountries() throws Exception{
        Database mySQL = new Database();
        boolean b= false;
        try {
            list = mySQL.getRoom();
            System.out.println(list);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }String result= "func( ["+  list.get(0) +" ," + list.get(1)  +" ," + list.get(2) +" ," + list.get(3)  +" ," + list.get(4)     +"])";
return result;
    } }


